# ViralForge AI

A production-ready AI-powered content creation SaaS for short-form creators. Users enter a topic or niche, choose a platform and style, then generate viral hooks, 30–90 second scripts, captions, titles, hashtags, content ideas, and 30-day content calendars.

Built for Vercel with:

- Next.js App Router + TypeScript
- Tailwind CSS dark premium SaaS UI
- Supabase Auth + Postgres + Row Level Security
- OpenAI server-side API integration
- Free daily usage limit: 5 successful AI generations/day
- Pro subscription-ready Stripe Checkout + webhook
- Copy, Save, Download, Regenerate, and content history
- User Dashboard, Generator, Calendar, Saved Projects, Settings, and Admin Dashboard

> Important: This app does **not** use fake AI responses. If `OPENAI_API_KEY` is missing, generation requests fail with a setup error instead of returning mock content.

---

## 1. Local setup

### Requirements

- Node.js 20+
- npm
- Supabase project
- OpenAI API key
- Optional: Stripe account for paid subscriptions

### Install dependencies

```bash
npm install
```

### Create environment file

Copy the example file:

```bash
cp .env.example .env.local
```

Fill in `.env.local`:

```bash
NEXT_PUBLIC_APP_URL=http://localhost:3000

NEXT_PUBLIC_SUPABASE_URL=your_supabase_project_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key

OPENAI_API_KEY=your_openai_api_key
OPENAI_MODEL=gpt-4o-mini

# Server-only, required only for Stripe webhook subscription updates
SUPABASE_SERVICE_ROLE_KEY=your_supabase_service_role_key

# Optional Stripe subscription billing
STRIPE_SECRET_KEY=sk_test_or_live...
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_PRO_PRICE_ID=price_...
```

Never put `OPENAI_API_KEY`, `STRIPE_SECRET_KEY`, or `SUPABASE_SERVICE_ROLE_KEY` in client-side code or expose them as `NEXT_PUBLIC_*` variables.

---

## 2. Supabase setup

1. Create a new project at <https://supabase.com>.
2. Open **Project Settings → API** and copy:
   - Project URL → `NEXT_PUBLIC_SUPABASE_URL`
   - anon public key → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - service_role key → `SUPABASE_SERVICE_ROLE_KEY` server-only
3. Open **SQL Editor**.
4. Copy and run the full SQL from:

```text
supabase/schema.sql
```

This creates:

- `profiles`
- `generations`
- `usage_events`
- auth profile trigger
- RLS policies
- admin helper function

### Optional: make yourself admin

After signing up, run this in Supabase SQL Editor:

```sql
update public.profiles
set role = 'admin', plan = 'admin'
where email = 'your-email@example.com';
```

Then visit `/admin`.

---

## 3. OpenAI setup

1. Create an API key from your OpenAI account.
2. Add it as `OPENAI_API_KEY` in `.env.local` and later in Vercel.
3. The default model is:

```bash
OPENAI_MODEL=gpt-4o-mini
```

You can change it to another JSON-capable model.

All AI calls happen in `src/app/api/generate/route.ts`, which runs server-side only.

---

## 4. Stripe setup, optional but ready

The app includes Stripe Checkout and webhook routes for Pro subscriptions.

### Create a product and price

1. In Stripe Dashboard, create a Product named `ViralForge AI Pro`.
2. Add a recurring monthly price.
3. Copy the price ID, for example `price_123`, into:

```bash
STRIPE_PRO_PRICE_ID=price_123
```

### Add webhook endpoint

After deploying, add a Stripe webhook endpoint:

```text
https://your-domain.com/api/stripe/webhook
```

Listen for these events:

- `checkout.session.completed`
- `customer.subscription.created`
- `customer.subscription.updated`
- `customer.subscription.deleted`

Copy the webhook signing secret into:

```bash
STRIPE_WEBHOOK_SECRET=whsec_...
```

The webhook updates the user's `profiles.plan` to `pro` when a subscription is active/trialing and back to `free` otherwise.

---

## 5. Run locally

```bash
npm run dev
```

Open:

```text
http://localhost:3000
```

Production build test:

```bash
npm run build
npm start
```

---

## 6. GitHub deployment flow

Create a GitHub repository, then run:

```bash
git init
git add .
git commit -m "Initial ViralForge AI app"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/viralforge-ai.git
git push -u origin main
```

Do not commit `.env.local`. It is already ignored.

---

## 7. Deploy to Vercel

1. Go to <https://vercel.com/new>.
2. Import your GitHub repository.
3. Framework preset should be **Next.js**.
4. Add these environment variables in **Project Settings → Environment Variables**:

Required:

```bash
NEXT_PUBLIC_APP_URL=https://your-vercel-domain.vercel.app
NEXT_PUBLIC_SUPABASE_URL=your_supabase_project_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
OPENAI_API_KEY=your_openai_api_key
OPENAI_MODEL=gpt-4o-mini
```

Recommended for Stripe:

```bash
SUPABASE_SERVICE_ROLE_KEY=your_supabase_service_role_key
STRIPE_SECRET_KEY=sk_live_or_test...
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_PRO_PRICE_ID=price_...
```

5. Click **Deploy**.
6. After deployment, update `NEXT_PUBLIC_APP_URL` to your final production URL.
7. In Supabase Auth settings, add your production URL to allowed redirect URLs:

```text
https://your-domain.com/auth/callback
```

Also add the local callback for development:

```text
http://localhost:3000/auth/callback
```

---

## 8. Feature map

### Public pages

- `/` Home
- `/features`
- `/pricing`
- `/login`
- `/signup`

### Authenticated app

- `/dashboard` usage overview and recent history
- `/generator` AI content pack generator
- `/calendar` 30-day calendar generator
- `/projects` saved projects and full content history
- `/settings` account/profile/subscription settings
- `/admin` admin-only platform overview

### API routes

- `POST /api/generate` real OpenAI generation, quota check, stores history
- `GET /api/projects` list content history/saved projects
- `PATCH /api/projects/[id]` save/unsave or rename project
- `DELETE /api/projects/[id]` delete project
- `GET /api/profile` profile and usage
- `PATCH /api/profile` update name
- `GET /api/admin/stats` admin stats
- `POST /api/stripe/checkout` create Stripe subscription checkout
- `POST /api/stripe/webhook` update subscription status

---

## 9. Usage limits

Free users are limited to 5 successful generations per calendar day. Usage is recorded only after a successful OpenAI generation and database save.

Pro/admin users are treated as unlimited by default in:

```text
src/lib/quota.ts
```

You can modify this file if you want a different Pro limit.

---

## 10. Security notes

- OpenAI API key is used only in server route code.
- Supabase RLS protects user data by `auth.uid()`.
- Service role key is only used by Stripe webhooks and must remain server-only.
- `.env.local` and `.env` are ignored by Git.
- The app returns setup errors if server credentials are missing rather than exposing or faking data.

---

## 11. Replace branding

Placeholder branding is in:

- `src/components/logo.tsx`
- `src/app/layout.tsx` metadata
- public/marketing copy inside `src/app/page.tsx`

You can replace the logo icon, product name, colors, and copy anytime.

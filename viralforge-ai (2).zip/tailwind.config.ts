import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        midnight: "#070A13",
        panel: "#0D1222",
        panel2: "#11182C",
        line: "rgba(255,255,255,0.10)"
      },
      boxShadow: {
        glow: "0 0 45px rgba(99, 102, 241, 0.22)",
        card: "0 20px 70px rgba(0,0,0,0.32)"
      },
      animation: {
        float: "float 6s ease-in-out infinite",
        pulseGlow: "pulseGlow 3s ease-in-out infinite"
      },
      keyframes: {
        float: {
          "0%, 100%": { transform: "translateY(0px)" },
          "50%": { transform: "translateY(-14px)" }
        },
        pulseGlow: {
          "0%, 100%": { opacity: "0.75" },
          "50%": { opacity: "1" }
        }
      }
    }
  },
  plugins: []
};
export default config;

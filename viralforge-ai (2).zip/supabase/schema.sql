-- ViralForge AI Supabase schema
-- Run this in Supabase SQL Editor before deploying the app.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  full_name text,
  plan text not null default 'free' check (plan in ('free', 'pro', 'admin')),
  role text not null default 'user' check (role in ('user', 'admin')),
  stripe_customer_id text,
  stripe_subscription_id text,
  subscription_status text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.generations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  kind text not null check (kind in ('content_pack', 'calendar')),
  platform text not null,
  topic text not null,
  style text not null,
  title text not null,
  result jsonb not null,
  is_saved boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.usage_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  generation_id uuid references public.generations(id) on delete set null,
  created_at timestamptz not null default now()
);

create index if not exists generations_user_created_idx on public.generations(user_id, created_at desc);
create index if not exists generations_user_saved_idx on public.generations(user_id, is_saved);
create index if not exists usage_events_user_created_idx on public.usage_events(user_id, created_at desc);

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists profiles_set_updated_at on public.profiles;
create trigger profiles_set_updated_at before update on public.profiles
for each row execute function public.set_updated_at();

drop trigger if exists generations_set_updated_at on public.generations;
create trigger generations_set_updated_at before update on public.generations
for each row execute function public.set_updated_at();

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email, full_name, plan, role)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'full_name', ''), 'free', 'user')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

create or replace function public.is_admin()
returns boolean
language sql
security definer
set search_path = public
stable
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and (role = 'admin' or plan = 'admin')
  );
$$;

alter table public.profiles enable row level security;
alter table public.generations enable row level security;
alter table public.usage_events enable row level security;

drop policy if exists "profiles_select_own_or_admin" on public.profiles;
create policy "profiles_select_own_or_admin" on public.profiles
for select using (auth.uid() = id or public.is_admin());

drop policy if exists "profiles_insert_own" on public.profiles;
create policy "profiles_insert_own" on public.profiles
for insert with check (auth.uid() = id);

drop policy if exists "profiles_update_own_or_admin" on public.profiles;
create policy "profiles_update_own_or_admin" on public.profiles
for update using (auth.uid() = id or public.is_admin())
with check (auth.uid() = id or public.is_admin());

drop policy if exists "generations_select_own_or_admin" on public.generations;
create policy "generations_select_own_or_admin" on public.generations
for select using (auth.uid() = user_id or public.is_admin());

drop policy if exists "generations_insert_own" on public.generations;
create policy "generations_insert_own" on public.generations
for insert with check (auth.uid() = user_id);

drop policy if exists "generations_update_own_or_admin" on public.generations;
create policy "generations_update_own_or_admin" on public.generations
for update using (auth.uid() = user_id or public.is_admin())
with check (auth.uid() = user_id or public.is_admin());

drop policy if exists "generations_delete_own_or_admin" on public.generations;
create policy "generations_delete_own_or_admin" on public.generations
for delete using (auth.uid() = user_id or public.is_admin());

drop policy if exists "usage_select_own_or_admin" on public.usage_events;
create policy "usage_select_own_or_admin" on public.usage_events
for select using (auth.uid() = user_id or public.is_admin());

drop policy if exists "usage_insert_own" on public.usage_events;
create policy "usage_insert_own" on public.usage_events
for insert with check (auth.uid() = user_id);

-- Make a user admin manually when needed:
-- update public.profiles set role = 'admin', plan = 'admin' where email = 'you@example.com';

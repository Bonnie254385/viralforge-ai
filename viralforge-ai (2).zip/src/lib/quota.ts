import type { SupabaseClient, User } from "@supabase/supabase-js";

export const FREE_DAILY_LIMIT = 5;

export function todayStartIso() {
  const now = new Date();
  return new Date(now.getFullYear(), now.getMonth(), now.getDate()).toISOString();
}

export async function ensureProfile(supabase: SupabaseClient, user: User) {
  const { data } = await supabase.from("profiles").select("*").eq("id", user.id).single();
  if (data) return data;

  const { data: inserted, error } = await supabase
    .from("profiles")
    .insert({ id: user.id, email: user.email, full_name: user.user_metadata?.full_name || "", plan: "free", role: "user" })
    .select("*")
    .single();
  if (error) throw new Error(error.message);
  return inserted;
}

export async function getUsageToday(supabase: SupabaseClient, userId: string) {
  const { count, error } = await supabase
    .from("usage_events")
    .select("id", { count: "exact", head: true })
    .eq("user_id", userId)
    .gte("created_at", todayStartIso());
  if (error) throw new Error(error.message);
  return count || 0;
}

export function hasUnlimitedUsage(profile: any) {
  return profile?.plan === "pro" || profile?.plan === "admin" || profile?.subscription_status === "active" || profile?.subscription_status === "trialing";
}

import OpenAI from "openai";

export type GenerateBody = {
  topic: string;
  platform: "TikTok" | "YouTube Shorts" | "Instagram Reels" | "Facebook Reels";
  style: string;
  audience?: string;
  tone?: string;
  kind: "content_pack" | "calendar";
};

export function buildPrompt(body: GenerateBody) {
  const base = `Topic or niche: ${body.topic}\nPlatform: ${body.platform}\nContent style: ${body.style}\nAudience: ${body.audience || "General audience"}\nTone: ${body.tone || "Energetic, professional, concise"}`;

  if (body.kind === "calendar") {
    return `${base}\n\nCreate a 30-day short-form content calendar. Return ONLY valid JSON with this exact shape:\n{\n  "summary": "short strategic summary",\n  "calendar_days": [\n    {"day": 1, "platform": "platform name", "title": "short title", "hook": "opening hook", "script_outline": "30-90 second outline", "caption": "caption", "hashtags": ["#tag"]}\n  ]\n}\nRequirements: include exactly 30 days; each day must be distinct, practical, and designed for short-form social video. Never include markdown fences.`;
  }

  return `${base}\n\nCreate a viral short-form content pack. Return ONLY valid JSON with this exact shape:\n{\n  "summary": "short strategy summary",\n  "viral_hooks": ["10 hooks"],\n  "scripts": [\n    {"duration_seconds": 30, "title": "script title", "script": "spoken script with shot directions and CTA"},\n    {"duration_seconds": 60, "title": "script title", "script": "spoken script with shot directions and CTA"},\n    {"duration_seconds": 90, "title": "script title", "script": "spoken script with shot directions and CTA"}\n  ],\n  "captions": ["5 captions"],\n  "titles": ["10 titles"],\n  "hashtags": ["20 relevant hashtags"],\n  "content_ideas": ["15 repeatable content ideas"]\n}\nRequirements: optimize for retention, curiosity, clarity, and platform-native language. Never include markdown fences.`;
}

export async function generateWithOpenAI(body: GenerateBody) {
  if (!process.env.OPENAI_API_KEY) {
    throw new Error("OPENAI_API_KEY is not configured. Add a real OpenAI API key to your server environment variables.");
  }

  const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  const completion = await openai.chat.completions.create({
    model: process.env.OPENAI_MODEL || "gpt-4o-mini",
    temperature: 0.85,
    response_format: { type: "json_object" },
    messages: [
      {
        role: "system",
        content: "You are ViralForge AI, an expert short-form social video strategist. Produce original, practical, platform-ready content. Return only strict JSON matching the requested schema."
      },
      { role: "user", content: buildPrompt(body) }
    ]
  });

  const content = completion.choices[0]?.message?.content;
  if (!content) throw new Error("The AI provider returned an empty response.");

  try {
    return JSON.parse(content);
  } catch {
    throw new Error("The AI provider returned invalid JSON. Please regenerate.");
  }
}

"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { Check, Loader2, Zap } from "lucide-react";
import { Button } from "@/components/button";
import { Card } from "@/components/card";

const plans = [
  {
    name: "Free",
    price: "$0",
    description: "For testing ViralForge AI and creating a few posts per day.",
    features: ["5 AI generations per day", "Viral hooks and scripts", "Captions, titles, hashtags", "Content history", "Saved projects"],
    cta: "Start free",
    href: "/signup",
    featured: false
  },
  {
    name: "Pro",
    price: "$19",
    description: "For creators and teams publishing consistently across channels.",
    features: ["Higher or unlimited usage", "30-day calendars", "Priority generation", "Saved project library", "Subscription-ready billing"],
    cta: "Upgrade to Pro",
    featured: true
  }
];

export default function PricingPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function startCheckout() {
    setLoading(true);
    setError("");
    try {
      const res = await fetch("/api/stripe/checkout", { method: "POST" });
      const data = await res.json();
      if (res.status === 401) {
        router.push("/login?next=/pricing");
        return;
      }
      if (!res.ok) throw new Error(data.error || "Unable to start checkout");
      window.location.href = data.url;
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="px-4 py-16 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-6xl">
        <div className="mx-auto max-w-3xl text-center">
          <p className="font-semibold text-blue-300">Pricing</p>
          <h1 className="mt-3 text-4xl font-black tracking-tight sm:text-5xl">Start free. Upgrade when you publish more.</h1>
          <p className="mt-5 text-lg text-slate-300">Free users get 5 AI generations daily. Pro checkout is Stripe-ready and activates when you add your Stripe environment variables.</p>
        </div>
        {error && <div className="mx-auto mt-8 max-w-2xl rounded-2xl border border-amber-400/20 bg-amber-400/10 p-4 text-sm text-amber-100">{error}</div>}
        <div className="mt-12 grid gap-6 md:grid-cols-2">
          {plans.map((plan) => (
            <Card key={plan.name} className={plan.featured ? "border-blue-400/40 bg-blue-500/10" : ""}>
              {plan.featured && <div className="mb-5 inline-flex items-center gap-2 rounded-full bg-blue-400/15 px-3 py-1 text-sm font-semibold text-blue-100"><Zap className="h-4 w-4" /> Popular</div>}
              <h2 className="text-2xl font-black">{plan.name}</h2>
              <p className="mt-2 text-slate-400">{plan.description}</p>
              <div className="mt-7 flex items-end gap-2"><span className="text-5xl font-black">{plan.price}</span><span className="pb-2 text-slate-400">/month</span></div>
              <ul className="mt-8 space-y-3">
                {plan.features.map((feature) => <li key={feature} className="flex gap-3 text-sm text-slate-300"><Check className="h-5 w-5 shrink-0 text-emerald-300" /> {feature}</li>)}
              </ul>
              <div className="mt-8">
                {plan.href ? <Link href={plan.href}><Button className="w-full">{plan.cta}</Button></Link> : <Button className="w-full" onClick={startCheckout} disabled={loading}>{loading ? <Loader2 className="h-4 w-4 animate-spin" /> : null}{plan.cta}</Button>}
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

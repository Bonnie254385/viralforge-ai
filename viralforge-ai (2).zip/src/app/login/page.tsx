"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { FormEvent, useState } from "react";
import { Loader2, LogIn } from "lucide-react";
import { Button } from "@/components/button";
import { Card } from "@/components/card";
import { createSupabaseBrowserClient } from "@/lib/supabase/browser";

export default function LoginPage() {
  const router = useRouter();
  const supabase = createSupabaseBrowserClient();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) return setError(error.message);
    const nextPath = new URLSearchParams(window.location.search).get("next") || "/dashboard";
    router.push(nextPath);
    router.refresh();
  }

  return (
    <section className="flex min-h-[calc(100vh-74px)] items-center justify-center px-4 py-12">
      <Card className="w-full max-w-md">
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-blue-500/20 text-blue-200"><LogIn /></div>
          <h1 className="text-3xl font-black">Welcome back</h1>
          <p className="mt-2 text-sm text-slate-400">Login to your ViralForge AI workspace.</p>
        </div>
        <form onSubmit={onSubmit} className="space-y-4">
          <label className="block text-sm font-semibold text-slate-200">Email<input required type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="mt-2 w-full rounded-xl px-4 py-3" /></label>
          <label className="block text-sm font-semibold text-slate-200">Password<input required minLength={6} type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="mt-2 w-full rounded-xl px-4 py-3" /></label>
          {error && <div className="rounded-xl border border-rose-400/20 bg-rose-400/10 p-3 text-sm text-rose-100">{error}</div>}
          <Button type="submit" className="w-full" disabled={loading}>{loading ? <Loader2 className="h-4 w-4 animate-spin" /> : null}Login</Button>
        </form>
        <p className="mt-6 text-center text-sm text-slate-400">No account? <Link href="/signup" className="font-semibold text-blue-300">Sign up free</Link></p>
      </Card>
    </section>
  );
}

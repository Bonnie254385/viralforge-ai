"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { CalendarDays, Folder, Loader2, Plus, Sparkles, Wand2 } from "lucide-react";
import { Button } from "@/components/button";
import { Card } from "@/components/card";

export default function DashboardPage() {
  const [profileData, setProfileData] = useState<any>(null);
  const [projects, setProjects] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const [profileRes, projectsRes] = await Promise.all([
      fetch("/api/profile"),
      fetch("/api/projects?limit=5")
    ]);
    if (profileRes.ok) setProfileData(await profileRes.json());
    if (projectsRes.ok) setProjects((await projectsRes.json()).projects || []);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  if (loading) return <div className="flex min-h-[60vh] items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-blue-300" /></div>;

  const profile = profileData?.profile || {};
  const remaining = profile.plan === "free" ? Math.max(0, profileData.freeDailyLimit - profileData.usageToday) : "Unlimited";

  return (
    <section className="px-4 py-10 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end">
          <div>
            <p className="text-sm font-semibold text-blue-300">Workspace</p>
            <h1 className="mt-2 text-3xl font-black sm:text-4xl">Welcome{profile.full_name ? `, ${profile.full_name}` : ""}</h1>
            <p className="mt-2 text-slate-400">Generate, save, and organize your short-form content.</p>
          </div>
          <Link href="/generator"><Button><Plus className="h-4 w-4" /> New generation</Button></Link>
        </div>

        <div className="mt-8 grid gap-5 md:grid-cols-3">
          <Card>
            <Sparkles className="mb-4 h-7 w-7 text-blue-300" />
            <p className="text-sm text-slate-400">Plan</p>
            <p className="mt-1 text-2xl font-black capitalize">{profile.plan || "free"}</p>
          </Card>
          <Card>
            <Wand2 className="mb-4 h-7 w-7 text-purple-300" />
            <p className="text-sm text-slate-400">Used today</p>
            <p className="mt-1 text-2xl font-black">{profileData?.usageToday || 0}</p>
          </Card>
          <Card>
            <CalendarDays className="mb-4 h-7 w-7 text-emerald-300" />
            <p className="text-sm text-slate-400">Remaining today</p>
            <p className="mt-1 text-2xl font-black">{remaining}</p>
          </Card>
        </div>

        <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_.8fr]">
          <Card>
            <div className="mb-5 flex items-center justify-between">
              <h2 className="text-xl font-black">Recent content history</h2>
              <Link href="/projects" className="text-sm font-semibold text-blue-300">View all</Link>
            </div>
            {projects.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-white/15 p-8 text-center text-slate-400">No generations yet. Create your first viral content pack.</div>
            ) : (
              <div className="space-y-3">
                {projects.map((project) => (
                  <Link key={project.id} href="/projects" className="block rounded-2xl border border-white/10 bg-white/5 p-4 transition hover:bg-white/10">
                    <div className="flex items-center justify-between gap-3">
                      <div>
                        <p className="font-semibold">{project.title}</p>
                        <p className="mt-1 text-sm text-slate-500">{project.platform} • {project.kind.replace("_", " ")} • {new Date(project.created_at).toLocaleString()}</p>
                      </div>
                      <Folder className="h-5 w-5 text-slate-500" />
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </Card>
          <Card className="bg-gradient-to-br from-blue-500/15 to-purple-500/15">
            <h2 className="text-xl font-black">Next best action</h2>
            <p className="mt-3 text-sm leading-6 text-slate-300">Create one topic-specific content pack, save the best hooks, then turn the same niche into a 30-day calendar.</p>
            <div className="mt-6 flex flex-col gap-3">
              <Link href="/generator"><Button className="w-full">Open AI Content Generator</Button></Link>
              <Link href="/calendar"><Button variant="secondary" className="w-full">Build 30-day Calendar</Button></Link>
            </div>
          </Card>
        </div>
      </div>
    </section>
  );
}

"use client";

import { FormEvent, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { CreditCard, Loader2, LogOut, Save } from "lucide-react";
import { Button } from "@/components/button";
import { Card } from "@/components/card";
import { createSupabaseBrowserClient } from "@/lib/supabase/browser";

export default function SettingsPage() {
  const [data, setData] = useState<any>(null);
  const [fullName, setFullName] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const router = useRouter();
  const supabase = createSupabaseBrowserClient();

  async function load() {
    setLoading(true);
    const res = await fetch("/api/profile");
    if (res.ok) {
      const json = await res.json();
      setData(json);
      setFullName(json.profile?.full_name || "");
    }
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function saveProfile(e: FormEvent) {
    e.preventDefault();
    setSaving(true);
    setMessage("");
    const res = await fetch("/api/profile", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ full_name: fullName }) });
    const json = await res.json();
    setSaving(false);
    if (!res.ok) return setMessage(json.error || "Could not save");
    setData((prev: any) => ({ ...prev, profile: json.profile }));
    setMessage("Profile updated");
  }

  async function upgrade() {
    setMessage("");
    const res = await fetch("/api/stripe/checkout", { method: "POST" });
    const json = await res.json();
    if (!res.ok) return setMessage(json.error || "Checkout failed");
    window.location.href = json.url;
  }

  async function signOut() {
    await supabase.auth.signOut();
    router.push("/");
    router.refresh();
  }

  if (loading) return <div className="flex min-h-[60vh] items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-blue-300" /></div>;

  const profile = data?.profile || {};

  return (
    <section className="px-4 py-10 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-4xl">
        <div className="mb-8">
          <p className="font-semibold text-blue-300">Account Settings</p>
          <h1 className="mt-2 text-3xl font-black sm:text-4xl">Manage your account</h1>
        </div>
        <div className="space-y-6">
          <Card>
            <h2 className="text-xl font-black">Profile</h2>
            <form onSubmit={saveProfile} className="mt-5 space-y-4">
              <label className="block text-sm font-semibold">Full name<input value={fullName} onChange={(e) => setFullName(e.target.value)} className="mt-2 w-full rounded-xl px-4 py-3" /></label>
              <label className="block text-sm font-semibold text-slate-400">Email<input value={profile.email || ""} disabled className="mt-2 w-full rounded-xl px-4 py-3 opacity-60" /></label>
              <Button type="submit" disabled={saving}>{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} Save profile</Button>
            </form>
          </Card>
          <Card>
            <h2 className="text-xl font-black">Subscription</h2>
            <div className="mt-5 grid gap-4 sm:grid-cols-3">
              <div className="rounded-2xl border border-white/10 bg-white/5 p-4"><p className="text-sm text-slate-400">Plan</p><p className="mt-1 text-2xl font-black capitalize">{profile.plan}</p></div>
              <div className="rounded-2xl border border-white/10 bg-white/5 p-4"><p className="text-sm text-slate-400">Usage today</p><p className="mt-1 text-2xl font-black">{data.usageToday}</p></div>
              <div className="rounded-2xl border border-white/10 bg-white/5 p-4"><p className="text-sm text-slate-400">Free limit</p><p className="mt-1 text-2xl font-black">{data.freeDailyLimit}/day</p></div>
            </div>
            <Button className="mt-5" onClick={upgrade}><CreditCard className="h-4 w-4" /> Upgrade / Manage Pro</Button>
          </Card>
          {message && <div className="rounded-2xl border border-blue-400/20 bg-blue-400/10 p-4 text-sm text-blue-100">{message}</div>}
          <Button variant="danger" onClick={signOut}><LogOut className="h-4 w-4" /> Sign out</Button>
        </div>
      </div>
    </section>
  );
}

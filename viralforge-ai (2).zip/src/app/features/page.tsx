import { BrainCircuit, CalendarRange, CopyCheck, Database, LockKeyhole, RefreshCcw, Save, Sparkles, Wand2, type LucideIcon } from "lucide-react";
import { Card } from "@/components/card";

const features: Array<[LucideIcon, string, string]> = [
  [Sparkles, "Viral hook engine", "Generate swipe-stopping hooks for curiosity, controversy, education, listicle, story, and problem/solution styles."],
  [Wand2, "Full content packs", "One prompt produces hooks, 30–90 second scripts, captions, titles, hashtags, and repeatable content ideas."],
  [CalendarRange, "30-day calendar", "Plan a complete month of niche-specific content with daily angle, outline, caption, and hashtags."],
  [CopyCheck, "Copy and download", "Copy output to your clipboard or download generated content as a text file for your content workflow."],
  [Save, "Saved projects", "Save your best generations and return to them from the project library."],
  [RefreshCcw, "Regenerate", "Re-run prompts with the same inputs when you need stronger angles or more variations."],
  [Database, "Content history", "Every successful AI generation is stored in your account history for easy retrieval."],
  [LockKeyhole, "Secure AI integration", "OpenAI API calls happen in server routes only. API keys are never exposed to browser code."],
  [BrainCircuit, "Production SaaS foundation", "Supabase auth, row-level security, usage limits, admin stats, and Stripe-ready subscriptions."],
];

export default function FeaturesPage() {
  return (
    <section className="px-4 py-16 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="max-w-3xl">
          <p className="font-semibold text-blue-300">Features</p>
          <h1 className="mt-3 text-4xl font-black tracking-tight sm:text-5xl">Everything creators need to publish faster.</h1>
          <p className="mt-5 text-lg leading-8 text-slate-300">ViralForge AI is built as a production-ready creator SaaS with secure authentication, real AI generation, daily limits, saving, history, and deployment instructions.</p>
        </div>
        <div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {features.map(([Icon, title, text]) => (
            <Card key={String(title)} className="transition hover:-translate-y-1 hover:border-purple-400/30">
              <Icon className="mb-5 h-7 w-7 text-purple-300" />
              <h2 className="text-xl font-bold">{title}</h2>
              <p className="mt-3 text-sm leading-6 text-slate-400">{text}</p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

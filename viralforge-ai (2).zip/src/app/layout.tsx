import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { Navbar } from "@/components/navbar";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "ViralForge AI | AI Content Creation Platform",
  description: "Generate viral short-form scripts, hooks, captions, hashtags, titles, ideas, and 30-day calendars for TikTok, Reels, Shorts, Facebook and Instagram.",
  metadataBase: new URL(process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000")
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className={`${inter.className} min-h-screen bg-midnight text-white antialiased`}>
        <div className="fixed inset-0 -z-10 grid-bg opacity-40" />
        <Navbar />
        <main>{children}</main>
      </body>
    </html>
  );
}

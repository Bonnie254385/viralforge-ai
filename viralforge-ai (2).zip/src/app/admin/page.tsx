"use client";

import { useEffect, useState } from "react";
import { BarChart3, Loader2, RefreshCcw, Shield, Users, Wand2 } from "lucide-react";
import { Button } from "@/components/button";
import { Card } from "@/components/card";

export default function AdminPage() {
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  async function load() {
    setLoading(true);
    setError("");
    const res = await fetch("/api/admin/stats");
    const json = await res.json();
    setLoading(false);
    if (!res.ok) return setError(json.error || "Unable to load admin stats");
    setStats(json);
  }

  useEffect(() => { load(); }, []);

  return (
    <section className="px-4 py-10 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="mb-8 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
          <div>
            <p className="font-semibold text-blue-300">Admin Dashboard</p>
            <h1 className="mt-2 text-3xl font-black sm:text-4xl">Platform overview</h1>
            <p className="mt-2 text-slate-400">Only profiles with role = admin can view these metrics.</p>
          </div>
          <Button variant="secondary" onClick={load} disabled={loading}><RefreshCcw className="h-4 w-4" /> Refresh</Button>
        </div>
        {loading ? <div className="flex min-h-[40vh] items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-blue-300" /></div> : error ? <Card className="border-rose-400/25 bg-rose-400/10"><Shield className="mb-4 h-8 w-8 text-rose-200" /><h2 className="text-xl font-black">Access unavailable</h2><p className="mt-2 text-slate-300">{error}</p></Card> : <div className="space-y-6"><div className="grid gap-5 md:grid-cols-3"><Card><Users className="mb-4 h-7 w-7 text-blue-300" /><p className="text-sm text-slate-400">Users</p><p className="mt-1 text-3xl font-black">{stats.users}</p></Card><Card><Wand2 className="mb-4 h-7 w-7 text-purple-300" /><p className="text-sm text-slate-400">Generations</p><p className="mt-1 text-3xl font-black">{stats.generations}</p></Card><Card><BarChart3 className="mb-4 h-7 w-7 text-emerald-300" /><p className="text-sm text-slate-400">Saved projects</p><p className="mt-1 text-3xl font-black">{stats.saved}</p></Card></div><Card><h2 className="mb-4 text-xl font-black">Recent generations</h2>{stats.recent.length === 0 ? <p className="text-sm text-slate-400">No activity yet.</p> : <div className="overflow-x-auto"><table className="w-full text-left text-sm"><thead className="text-slate-500"><tr><th className="py-3">Title</th><th>Platform</th><th>Type</th><th>Created</th></tr></thead><tbody>{stats.recent.map((item: any) => <tr key={item.id} className="border-t border-white/10"><td className="py-3 pr-4 font-medium">{item.title}</td><td className="pr-4 text-slate-400">{item.platform}</td><td className="pr-4 text-slate-400">{item.kind}</td><td className="text-slate-500">{new Date(item.created_at).toLocaleString()}</td></tr>)}</tbody></table></div>}</Card></div>}
      </div>
    </section>
  );
}

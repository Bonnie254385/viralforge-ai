import { NextResponse } from "next/server";
import { createSupabaseServerClient } from "@/lib/supabase/server";

export async function GET() {
  const supabase = createSupabaseServerClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { data: profile } = await supabase.from("profiles").select("role, plan").eq("id", user.id).single();
  if (profile?.role !== "admin" && profile?.plan !== "admin") return NextResponse.json({ error: "Admin access required" }, { status: 403 });

  const [{ count: users }, { count: generations }, { count: saved }, { data: recent }] = await Promise.all([
    supabase.from("profiles").select("id", { count: "exact", head: true }),
    supabase.from("generations").select("id", { count: "exact", head: true }),
    supabase.from("generations").select("id", { count: "exact", head: true }).eq("is_saved", true),
    supabase.from("generations").select("id,title,topic,platform,kind,created_at,user_id").order("created_at", { ascending: false }).limit(10)
  ]);

  return NextResponse.json({ users: users || 0, generations: generations || 0, saved: saved || 0, recent: recent || [] });
}

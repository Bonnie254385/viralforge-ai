import { NextResponse } from "next/server";

export const maxDuration = 60;
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { FREE_DAILY_LIMIT, ensureProfile, getUsageToday, hasUnlimitedUsage } from "@/lib/quota";
import { generateWithOpenAI, type GenerateBody } from "@/lib/ai";

const platforms = ["TikTok", "YouTube Shorts", "Instagram Reels", "Facebook Reels"];
const kinds = ["content_pack", "calendar"];

function validate(body: any): GenerateBody {
  if (!body?.topic || typeof body.topic !== "string" || body.topic.trim().length < 3) throw new Error("Enter a topic or niche with at least 3 characters.");
  if (!platforms.includes(body.platform)) throw new Error("Choose a valid platform.");
  if (!body?.style || typeof body.style !== "string") throw new Error("Choose a content style.");
  if (!kinds.includes(body.kind)) throw new Error("Choose a valid generation type.");
  return {
    topic: body.topic.trim().slice(0, 500),
    platform: body.platform,
    style: body.style.slice(0, 100),
    audience: typeof body.audience === "string" ? body.audience.slice(0, 200) : "",
    tone: typeof body.tone === "string" ? body.tone.slice(0, 100) : "",
    kind: body.kind
  };
}

export async function POST(request: Request) {
  try {
    const supabase = createSupabaseServerClient();
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const body = validate(await request.json());
    const profile = await ensureProfile(supabase, user);
    const usageToday = await getUsageToday(supabase, user.id);
    const unlimited = hasUnlimitedUsage(profile);

    if (!unlimited && usageToday >= FREE_DAILY_LIMIT) {
      return NextResponse.json({ error: `Daily free limit reached (${FREE_DAILY_LIMIT}/day). Upgrade to Pro for higher or unlimited usage.` }, { status: 429 });
    }

    const result = await generateWithOpenAI(body);

    const { data: generation, error: insertError } = await supabase
      .from("generations")
      .insert({
        user_id: user.id,
        kind: body.kind,
        platform: body.platform,
        topic: body.topic,
        style: body.style,
        title: body.kind === "calendar" ? `30-day calendar: ${body.topic}` : `Content pack: ${body.topic}`,
        result,
        is_saved: false
      })
      .select("*")
      .single();

    if (insertError) throw new Error(insertError.message);

    const { error: usageError } = await supabase.from("usage_events").insert({ user_id: user.id, generation_id: generation.id });
    if (usageError) throw new Error(usageError.message);

    return NextResponse.json({ generation, remainingToday: unlimited ? null : Math.max(0, FREE_DAILY_LIMIT - usageToday - 1) });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || "Generation failed" }, { status: 500 });
  }
}

"use client";

import { useEffect, useMemo, useState } from "react";
import { Loader2, Search } from "lucide-react";
import { Button } from "@/components/button";
import { Card } from "@/components/card";
import { GenerationView } from "@/components/generation-view";
import { ProjectActions } from "@/components/project-actions";

export default function ProjectsPage() {
  const [projects, setProjects] = useState<any[]>([]);
  const [selected, setSelected] = useState<any>(null);
  const [filter, setFilter] = useState("all");
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const params = filter === "saved" ? "?saved=true&limit=100" : "?limit=100";
    const res = await fetch(`/api/projects${params}`);
    if (res.ok) {
      const data = await res.json();
      setProjects(data.projects || []);
      setSelected((prev: any) => prev || data.projects?.[0] || null);
    }
    setLoading(false);
  }

  useEffect(() => { load(); }, [filter]);

  const filtered = useMemo(() => {
    return projects.filter((p) => `${p.title} ${p.topic} ${p.platform}`.toLowerCase().includes(query.toLowerCase()));
  }, [projects, query]);

  function handleChange(project: any | null) {
    if (!project) {
      setProjects((items) => items.filter((item) => item.id !== selected?.id));
      setSelected(null);
      return;
    }
    setProjects((items) => items.map((item) => item.id === project.id ? project : item));
    setSelected(project);
  }

  return (
    <section className="px-4 py-10 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="mb-8">
          <p className="font-semibold text-blue-300">Saved Projects</p>
          <h1 className="mt-2 text-3xl font-black sm:text-4xl">Your content library</h1>
          <p className="mt-2 text-slate-400">Search history, open saved projects, copy, download, save, unsave, or delete generations.</p>
        </div>
        <div className="grid gap-6 lg:grid-cols-[.8fr_1.2fr]">
          <Card className="h-fit">
            <div className="mb-4 flex gap-2">
              <Button variant={filter === "all" ? "primary" : "secondary"} onClick={() => setFilter("all")}>All</Button>
              <Button variant={filter === "saved" ? "primary" : "secondary"} onClick={() => setFilter("saved")}>Saved</Button>
            </div>
            <div className="relative mb-4">
              <Search className="absolute left-3 top-3.5 h-4 w-4 text-slate-500" />
              <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search projects" className="w-full rounded-xl py-3 pl-10 pr-4" />
            </div>
            {loading ? <div className="flex justify-center py-10"><Loader2 className="h-7 w-7 animate-spin text-blue-300" /></div> : filtered.length === 0 ? <div className="rounded-2xl border border-dashed border-white/15 p-8 text-center text-sm text-slate-400">No projects found.</div> : <div className="max-h-[65vh] space-y-3 overflow-auto pr-1">{filtered.map((project) => <button key={project.id} onClick={() => setSelected(project)} className={`w-full rounded-2xl border p-4 text-left transition ${selected?.id === project.id ? "border-blue-400/50 bg-blue-500/10" : "border-white/10 bg-white/5 hover:bg-white/10"}`}><div className="flex items-start justify-between gap-3"><div><p className="font-semibold">{project.title}</p><p className="mt-1 text-xs text-slate-500">{project.platform} • {project.kind.replace("_", " ")}</p><p className="mt-1 text-xs text-slate-600">{new Date(project.created_at).toLocaleString()}</p></div>{project.is_saved && <span className="rounded-full bg-purple-400/15 px-2 py-1 text-xs text-purple-100">Saved</span>}</div></button>)}</div>}
          </Card>
          <Card>
            {!selected ? <div className="rounded-2xl border border-dashed border-white/15 p-10 text-center text-slate-400">Select a project to preview it.</div> : <div className="space-y-5"><div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-start"><div><h2 className="text-2xl font-black">{selected.title}</h2><p className="mt-1 text-sm text-slate-500">{selected.platform} • {new Date(selected.created_at).toLocaleString()}</p></div><ProjectActions project={selected} onChange={handleChange} showDelete /></div><GenerationView result={selected.result} /></div>}
          </Card>
        </div>
      </div>
    </section>
  );
}

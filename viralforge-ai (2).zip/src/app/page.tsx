import Link from "next/link";
import { ArrowRight, CalendarDays, Clapperboard, Hash, Rocket, ShieldCheck, Sparkles, Wand2 } from "lucide-react";
import { Button } from "@/components/button";
import { Card } from "@/components/card";

const platforms = ["TikTok", "YouTube Shorts", "Instagram Reels", "Facebook Reels"];
const features = [
  { icon: Sparkles, title: "Viral hooks", text: "Create pattern-interrupt openers optimized for short-form attention spans." },
  { icon: Clapperboard, title: "30–90 second scripts", text: "Generate structured scripts with shots, pacing, CTA, and retention beats." },
  { icon: Hash, title: "Captions & hashtags", text: "Platform-ready captions, titles, keywords, and hashtag sets." },
  { icon: CalendarDays, title: "30-day calendars", text: "Turn one niche into a month of consistent content ideas and scripts." }
];

export default function HomePage() {
  return (
    <>
      <section className="relative overflow-hidden px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
        <div className="mx-auto grid max-w-7xl items-center gap-12 lg:grid-cols-[1.05fr_.95fr]">
          <div>
            <div className="mb-6 inline-flex rounded-full border border-blue-400/20 bg-blue-400/10 px-4 py-2 text-sm font-semibold text-blue-100">
              AI content engine for short-form creators
            </div>
            <h1 className="max-w-4xl text-4xl font-black tracking-tight sm:text-6xl lg:text-7xl">
              Forge viral short-form content in <span className="gradient-text">seconds</span>.
            </h1>
            <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-300">
              ViralForge AI helps creators generate viral hooks, video scripts, captions, titles, hashtags, content ideas, and full 30-day calendars for the platforms that matter.
            </p>
            <div className="mt-9 flex flex-col gap-3 sm:flex-row">
              <Link href="/signup"><Button className="w-full sm:w-auto">Start creating free <ArrowRight className="h-4 w-4" /></Button></Link>
              <Link href="/features"><Button variant="secondary" className="w-full sm:w-auto">Explore features</Button></Link>
            </div>
            <div className="mt-8 flex flex-wrap gap-2 text-sm text-slate-300">
              {platforms.map((platform) => <span key={platform} className="rounded-full border border-white/10 bg-white/5 px-3 py-1">{platform}</span>)}
            </div>
          </div>
          <Card className="relative animate-float overflow-hidden p-0">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/20 via-transparent to-purple-500/20" />
            <div className="relative p-6 sm:p-8">
              <div className="mb-5 flex items-center justify-between">
                <div>
                  <p className="text-sm text-slate-400">Generator</p>
                  <h2 className="text-2xl font-bold">Viral Content Pack</h2>
                </div>
                <Wand2 className="h-8 w-8 text-purple-300" />
              </div>
              <div className="space-y-4">
                <div className="rounded-2xl border border-white/10 bg-black/25 p-4">
                  <p className="text-xs uppercase tracking-wide text-slate-500">Topic</p>
                  <p className="mt-1 text-lg font-semibold">Healthy lunch prep for busy founders</p>
                </div>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="rounded-2xl border border-white/10 bg-black/25 p-4">
                    <p className="text-xs uppercase tracking-wide text-slate-500">Hook</p>
                    <p className="mt-2 text-slate-200">Stop buying overpriced lunches. Build five founder meals in 20 minutes.</p>
                  </div>
                  <div className="rounded-2xl border border-white/10 bg-black/25 p-4">
                    <p className="text-xs uppercase tracking-wide text-slate-500">Output</p>
                    <p className="mt-2 text-slate-200">Scripts, captions, titles, hashtags, ideas, calendar.</p>
                  </div>
                </div>
                <div className="rounded-2xl bg-gradient-to-r from-blue-500 to-purple-500 p-[1px]">
                  <div className="rounded-2xl bg-midnight/95 p-4">
                    <p className="font-semibold text-white">Ready to publish</p>
                    <p className="mt-1 text-sm text-slate-400">Copy, save, download, regenerate, and keep a full content history.</p>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </section>

      <section className="px-4 pb-20 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            {features.map((feature) => (
              <Card key={feature.title} className="transition hover:-translate-y-1 hover:border-blue-400/30">
                <feature.icon className="mb-5 h-7 w-7 text-blue-300" />
                <h3 className="text-xl font-bold">{feature.title}</h3>
                <p className="mt-3 text-sm leading-6 text-slate-400">{feature.text}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="px-4 pb-24 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-5xl rounded-[2rem] border border-white/10 bg-gradient-to-r from-blue-500/20 via-indigo-500/20 to-purple-500/20 p-8 text-center shadow-glow sm:p-12">
          <Rocket className="mx-auto mb-5 h-10 w-10 text-blue-200" />
          <h2 className="text-3xl font-black sm:text-4xl">Ship more content. Waste less time.</h2>
          <p className="mx-auto mt-4 max-w-2xl text-slate-300">Free creators get 5 AI generations per day. Upgrade-ready architecture supports Stripe subscriptions for higher or unlimited usage.</p>
          <div className="mt-8 flex items-center justify-center gap-3 text-sm text-slate-300"><ShieldCheck className="h-4 w-4 text-emerald-300" /> API keys stay on the server with secure environment variables.</div>
        </div>
      </section>
    </>
  );
}

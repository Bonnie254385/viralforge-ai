"use client";

import { FormEvent, useEffect, useState } from "react";
import { Loader2, RefreshCcw, Wand2 } from "lucide-react";
import { Button } from "@/components/button";
import { Card } from "@/components/card";
import { GenerationView } from "@/components/generation-view";
import { ProjectActions } from "@/components/project-actions";

const platforms = ["TikTok", "YouTube Shorts", "Instagram Reels", "Facebook Reels"];
const styles = ["Educational", "Storytelling", "Controversial", "Listicle", "Problem/Solution", "Product Promo", "Founder POV", "Tutorial"];

export default function GeneratorPage() {
  const [topic, setTopic] = useState("");
  const [platform, setPlatform] = useState("TikTok");
  const [style, setStyle] = useState("Educational");
  const [audience, setAudience] = useState("");
  const [tone, setTone] = useState("Energetic and professional");
  const [current, setCurrent] = useState<any>(null);
  const [history, setHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [remaining, setRemaining] = useState<any>(null);
  const [lastBody, setLastBody] = useState<any>(null);

  async function loadHistory() {
    const res = await fetch("/api/projects?kind=content_pack&limit=8");
    if (res.ok) setHistory((await res.json()).projects || []);
  }
  useEffect(() => { loadHistory(); }, []);

  async function generate(body?: any) {
    const payload = body || { topic, platform, style, audience, tone, kind: "content_pack" };
    setLoading(true);
    setError("");
    const res = await fetch("/api/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    setLoading(false);
    if (!res.ok) return setError(data.error || "Generation failed");
    setCurrent(data.generation);
    setRemaining(data.remainingToday);
    setLastBody(payload);
    await loadHistory();
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    generate();
  }

  return (
    <section className="px-4 py-10 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="mb-8 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
          <div>
            <p className="font-semibold text-blue-300">AI Content Generator</p>
            <h1 className="mt-2 text-3xl font-black sm:text-4xl">Generate a viral content pack</h1>
            <p className="mt-2 text-slate-400">Hooks, 30–90 second scripts, captions, titles, hashtags, and ideas.</p>
          </div>
          {remaining !== null && remaining !== undefined && <div className="rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm text-slate-300">Remaining today: {remaining === null ? "Unlimited" : remaining}</div>}
        </div>

        <div className="grid gap-6 lg:grid-cols-[.85fr_1.15fr]">
          <Card className="h-fit">
            <form onSubmit={onSubmit} className="space-y-4">
              <label className="block text-sm font-semibold">Topic or niche<textarea required minLength={3} value={topic} onChange={(e) => setTopic(e.target.value)} placeholder="Example: productivity tips for real estate agents" className="mt-2 min-h-28 w-full rounded-xl px-4 py-3" /></label>
              <div className="grid gap-4 sm:grid-cols-2">
                <label className="block text-sm font-semibold">Platform<select value={platform} onChange={(e) => setPlatform(e.target.value)} className="mt-2 w-full rounded-xl px-4 py-3">{platforms.map((p) => <option key={p}>{p}</option>)}</select></label>
                <label className="block text-sm font-semibold">Content style<select value={style} onChange={(e) => setStyle(e.target.value)} className="mt-2 w-full rounded-xl px-4 py-3">{styles.map((s) => <option key={s}>{s}</option>)}</select></label>
              </div>
              <label className="block text-sm font-semibold">Target audience<input value={audience} onChange={(e) => setAudience(e.target.value)} placeholder="Example: first-time founders" className="mt-2 w-full rounded-xl px-4 py-3" /></label>
              <label className="block text-sm font-semibold">Tone<input value={tone} onChange={(e) => setTone(e.target.value)} className="mt-2 w-full rounded-xl px-4 py-3" /></label>
              {error && <div className="rounded-xl border border-rose-400/20 bg-rose-400/10 p-3 text-sm text-rose-100">{error}</div>}
              <Button type="submit" className="w-full" disabled={loading}>{loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Wand2 className="h-4 w-4" />} Generate content</Button>
              <Button type="button" variant="secondary" className="w-full" disabled={loading || !lastBody} onClick={() => generate(lastBody)}><RefreshCcw className="h-4 w-4" /> Regenerate</Button>
            </form>
          </Card>

          <div className="space-y-6">
            <Card>
              <div className="mb-5 flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
                <h2 className="text-xl font-black">Generated output</h2>
                {current && <ProjectActions project={current} onChange={setCurrent} />}
              </div>
              {!current ? <div className="rounded-2xl border border-dashed border-white/15 p-10 text-center text-slate-400">Your AI content pack will appear here.</div> : <GenerationView result={current.result} />}
            </Card>

            <Card>
              <h2 className="mb-4 text-xl font-black">Content history</h2>
              {history.length === 0 ? <p className="text-sm text-slate-400">No history yet.</p> : <div className="space-y-3">{history.map((item) => <button key={item.id} onClick={() => setCurrent(item)} className="w-full rounded-2xl border border-white/10 bg-white/5 p-4 text-left transition hover:bg-white/10"><p className="font-semibold">{item.title}</p><p className="mt-1 text-xs text-slate-500">{new Date(item.created_at).toLocaleString()} • {item.platform}</p></button>)}</div>}
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}

import { Sparkles } from "lucide-react";

export function Logo() {
  return (
    <div className="flex items-center gap-3">
      <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-500 to-purple-500 shadow-glow">
        <Sparkles className="h-5 w-5 text-white" />
      </div>
      <span className="text-lg font-black tracking-tight">ViralForge <span className="gradient-text">AI</span></span>
    </div>
  );
}

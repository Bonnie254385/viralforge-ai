import { Card } from "@/components/card";

type Props = { result: any };

function List({ title, items }: { title: string; items?: any[] }) {
  if (!Array.isArray(items) || items.length === 0) return null;
  return (
    <div className="rounded-2xl border border-white/10 bg-black/20 p-4">
      <h3 className="mb-3 font-bold text-white">{title}</h3>
      <ol className="space-y-2 text-sm text-slate-300">
        {items.map((item, idx) => <li key={idx} className="leading-6">{typeof item === "string" ? item : JSON.stringify(item)}</li>)}
      </ol>
    </div>
  );
}

export function GenerationView({ result }: Props) {
  if (!result) return null;

  if (Array.isArray(result.calendar_days)) {
    return (
      <div className="space-y-5">
        {result.summary && <p className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm leading-6 text-slate-300">{result.summary}</p>}
        <div className="grid gap-4 lg:grid-cols-2">
          {result.calendar_days.map((day: any) => (
            <Card key={day.day} className="p-5">
              <div className="mb-3 flex items-center justify-between gap-3">
                <span className="rounded-full bg-blue-400/15 px-3 py-1 text-sm font-bold text-blue-100">Day {day.day}</span>
                <span className="text-xs text-slate-500">{day.platform}</span>
              </div>
              <h3 className="text-lg font-bold">{day.title}</h3>
              <p className="mt-3 text-sm text-blue-200"><strong>Hook:</strong> {day.hook}</p>
              <p className="mt-3 text-sm leading-6 text-slate-300"><strong>Outline:</strong> {day.script_outline}</p>
              <p className="mt-3 text-sm leading-6 text-slate-400"><strong>Caption:</strong> {day.caption}</p>
              {Array.isArray(day.hashtags) && <p className="mt-3 text-sm text-purple-200">{day.hashtags.join(" ")}</p>}
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {result.summary && <p className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm leading-6 text-slate-300">{result.summary}</p>}
      <div className="grid gap-4 lg:grid-cols-2">
        <List title="Viral hooks" items={result.viral_hooks} />
        <List title="Captions" items={result.captions} />
        <List title="Titles" items={result.titles} />
        <List title="Hashtags" items={result.hashtags} />
      </div>
      {Array.isArray(result.scripts) && (
        <div className="space-y-4">
          <h3 className="text-xl font-black">Scripts</h3>
          {result.scripts.map((script: any, idx: number) => (
            <Card key={idx} className="p-5">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <h4 className="text-lg font-bold">{script.title}</h4>
                <span className="rounded-full bg-purple-400/15 px-3 py-1 text-sm text-purple-100">{script.duration_seconds}s</span>
              </div>
              <p className="mt-4 whitespace-pre-wrap text-sm leading-7 text-slate-300">{script.script}</p>
            </Card>
          ))}
        </div>
      )}
      <List title="Content ideas" items={result.content_ideas} />
    </div>
  );
}

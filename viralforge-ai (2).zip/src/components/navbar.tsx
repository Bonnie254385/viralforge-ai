"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";
import { Logo } from "@/components/logo";
import { Button } from "@/components/button";
import { createSupabaseBrowserClient } from "@/lib/supabase/browser";

const marketingLinks = [
  { href: "/features", label: "Features" },
  { href: "/pricing", label: "Pricing" }
];

const appLinks = [
  { href: "/dashboard", label: "Dashboard" },
  { href: "/generator", label: "Generator" },
  { href: "/calendar", label: "Calendar" },
  { href: "/projects", label: "Projects" }
];

export function Navbar() {
  const [open, setOpen] = useState(false);
  const [authed, setAuthed] = useState<boolean | null>(null);
  const pathname = usePathname();
  const router = useRouter();
  const supabase = createSupabaseBrowserClient();

  useEffect(() => {
    let mounted = true;
    supabase.auth.getSession().then(({ data }) => mounted && setAuthed(Boolean(data.session)));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setAuthed(Boolean(session));
      router.refresh();
    });
    return () => {
      mounted = false;
      listener.subscription.unsubscribe();
    };
  }, [router, supabase.auth]);

  async function signOut() {
    await supabase.auth.signOut();
    setOpen(false);
    router.push("/");
    router.refresh();
  }

  const links = authed ? [...appLinks] : marketingLinks;

  return (
    <header className="sticky top-0 z-40 border-b border-white/10 bg-midnight/70 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
        <Link href="/" aria-label="ViralForge AI home"><Logo /></Link>
        <nav className="hidden items-center gap-1 md:flex">
          {links.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={`rounded-xl px-3 py-2 text-sm font-medium transition hover:bg-white/10 ${pathname === link.href ? "bg-white/10 text-white" : "text-slate-300"}`}
            >
              {link.label}
            </Link>
          ))}
          {authed && (
            <Link href="/settings" className="rounded-xl px-3 py-2 text-sm font-medium text-slate-300 transition hover:bg-white/10">Settings</Link>
          )}
        </nav>
        <div className="hidden items-center gap-3 md:flex">
          {authed ? (
            <Button variant="secondary" onClick={signOut}>Sign out</Button>
          ) : (
            <>
              <Link href="/login" className="rounded-xl px-4 py-2 text-sm font-semibold text-slate-200 hover:bg-white/10">Login</Link>
              <Link href="/signup"><Button>Start free</Button></Link>
            </>
          )}
        </div>
        <button className="rounded-xl p-2 hover:bg-white/10 md:hidden" onClick={() => setOpen(!open)} aria-label="Toggle menu">
          {open ? <X /> : <Menu />}
        </button>
      </div>
      {open && (
        <div className="border-t border-white/10 px-4 pb-4 md:hidden">
          <div className="flex flex-col gap-2 py-3">
            {links.map((link) => <Link onClick={() => setOpen(false)} key={link.href} href={link.href} className="rounded-xl px-3 py-2 text-sm font-medium text-slate-200 hover:bg-white/10">{link.label}</Link>)}
            {authed && <Link onClick={() => setOpen(false)} href="/settings" className="rounded-xl px-3 py-2 text-sm font-medium text-slate-200 hover:bg-white/10">Settings</Link>}
          </div>
          {authed ? <Button variant="secondary" className="w-full" onClick={signOut}>Sign out</Button> : <Link onClick={() => setOpen(false)} href="/signup"><Button className="w-full">Start free</Button></Link>}
        </div>
      )}
    </header>
  );
}

import * as React from "react";
import { cn } from "@/lib/utils";

type ButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary" | "ghost" | "danger";
};

export function Button({ className, variant = "primary", ...props }: ButtonProps) {
  const variants = {
    primary: "bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500 text-white shadow-glow hover:scale-[1.01]",
    secondary: "bg-white/10 text-white border border-white/10 hover:bg-white/15",
    ghost: "bg-transparent text-slate-200 hover:bg-white/10",
    danger: "bg-rose-500/15 text-rose-200 border border-rose-400/25 hover:bg-rose-500/25"
  };
  return (
    <button
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition duration-200 disabled:hover:scale-100",
        variants[variant],
        className
      )}
      {...props}
    />
  );
}

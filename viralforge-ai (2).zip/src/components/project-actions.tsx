"use client";

import { useState } from "react";
import { Copy, Download, Save, Trash2 } from "lucide-react";
import { Button } from "@/components/button";
import { downloadText, formatGeneration } from "@/lib/utils";

type Props = {
  project: any;
  onChange?: (project: any | null) => void;
  showDelete?: boolean;
};

export function ProjectActions({ project, onChange, showDelete = false }: Props) {
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  async function copy() {
    await navigator.clipboard.writeText(formatGeneration(project.result));
    setMessage("Copied");
  }

  function download() {
    downloadText(`${project.title || "viralforge-generation"}.txt`.replace(/[^a-z0-9_.-]/gi, "-"), formatGeneration(project.result));
    setMessage("Downloaded");
  }

  async function toggleSave() {
    setBusy(true);
    setMessage("");
    const res = await fetch(`/api/projects/${project.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ is_saved: !project.is_saved })
    });
    const data = await res.json();
    setBusy(false);
    if (!res.ok) return setMessage(data.error || "Unable to update");
    setMessage(data.project.is_saved ? "Saved" : "Unsaved");
    onChange?.(data.project);
  }

  async function remove() {
    if (!confirm("Delete this project?")) return;
    setBusy(true);
    const res = await fetch(`/api/projects/${project.id}`, { method: "DELETE" });
    setBusy(false);
    if (!res.ok) return setMessage("Delete failed");
    onChange?.(null);
  }

  return (
    <div className="flex flex-wrap items-center gap-2">
      <Button variant="secondary" onClick={copy}><Copy className="h-4 w-4" /> Copy</Button>
      <Button variant="secondary" onClick={download}><Download className="h-4 w-4" /> Download</Button>
      <Button variant="secondary" onClick={toggleSave} disabled={busy}><Save className="h-4 w-4" /> {project.is_saved ? "Unsave" : "Save"}</Button>
      {showDelete && <Button variant="danger" onClick={remove} disabled={busy}><Trash2 className="h-4 w-4" /> Delete</Button>}
      {message && <span className="text-sm text-slate-400">{message}</span>}
    </div>
  );
}

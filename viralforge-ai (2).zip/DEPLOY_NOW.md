# Deploy ViralForge AI Online

The full application code is complete and ready for Vercel.

## What you still need to provide inside Vercel/Supabase dashboards

You do not need to edit code. You only need to create accounts and paste environment variables.

Required:

1. Supabase project URL
2. Supabase anon key
3. OpenAI API key
4. Vercel account connected to GitHub

Optional for paid Pro subscriptions:

1. Stripe secret key
2. Stripe price ID
3. Stripe webhook secret
4. Supabase service role key

## Fast deployment path

1. Unzip `viralforge-ai.zip`.
2. Upload/push the folder to a GitHub repository.
3. Create a Supabase project.
4. Run `supabase/schema.sql` in Supabase SQL Editor.
5. Import the GitHub repo into Vercel.
6. Add the environment variables from `.env.example` into Vercel.
7. Click Deploy.

## Required Vercel environment variables

```bash
NEXT_PUBLIC_APP_URL=https://your-vercel-domain.vercel.app
NEXT_PUBLIC_SUPABASE_URL=your_supabase_project_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
OPENAI_API_KEY=your_openai_api_key
OPENAI_MODEL=gpt-4o-mini
```

## Optional Vercel environment variables for subscriptions

```bash
SUPABASE_SERVICE_ROLE_KEY=your_supabase_service_role_key
STRIPE_SECRET_KEY=your_stripe_secret_key
STRIPE_WEBHOOK_SECRET=your_stripe_webhook_secret
STRIPE_PRO_PRICE_ID=your_stripe_price_id
```

## Supabase redirect URLs

Add these in Supabase Authentication URL Configuration:

```text
http://localhost:3000/auth/callback
https://your-vercel-domain.vercel.app/auth/callback
```

## Important

Do not send private API keys in chat. Paste them directly into Vercel and Supabase dashboards.
